
<?php
/*
Plugin Name: OmerDemirel Wp-Cron Kapatma
Plugin URI:  https://omerdemirel.com.tr/wp-cron-kapatma/
Description: WooCommerce Wp-Cron Devre Dışı Bırakma
Version:     1.0
Author:      Ömer Faruk Demirel
Author URI:  omerdemirel.com.tr
License:     GNU
License URI: https://www.gnu.org/licenses/gpl-3.0.tr.html
*/

define('DISABLE_WP_CRON', true);
define( 'ALTERNATE_WP_CRON', false );